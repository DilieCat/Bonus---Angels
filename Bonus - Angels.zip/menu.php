<ul class="menu">
			<li><a href="index.php" <?php if($title == "Angels") { echo "class=\"active\""; } ?>>Home</a></li>
			<li><a href="heavens.php" <?php  if($title == "Heavens") { echo "class=\"active\""; } ?>>The High Heavens</a></li>
			<li><a href="guardian.php" <?php  if($title == "Guardian") { echo "class=\"active\""; } ?>>Guardian Angel</a></li>
			<li><a href="evolution.php" <?php  if($title == "Evolution") { echo "class=\"active\""; }  ?>>Our Evolution</a></li>
		</ul>
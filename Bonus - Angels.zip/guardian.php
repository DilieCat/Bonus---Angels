<?php 
$page = "guardian";
include 'top.php';
$title = "Guardian";
$header = "Guardian Angel"; 
?>

<body>
	<div class="frame">
		<?php include 'header.php';?>
		<?php include 'menu.php';?>
		<div class="content">
			<p class="uppertext">Cras dapibus dapibus nisl. Vestibulum quis dolor a felis congue vehicula. Maecenas pede purus, tristique ac, tempus eget, egestas quis, mauris.</p>
			<div class="article">
				<h2>When ever you need me</h2>
				
				<p><img src="angel2.gif" class="img-topright"/>Mauris et nisl enim, non pellentesque elit. Etiam condimentum dapibus arcu, quis vestibulum risus vulputate sed. Etiam venenatis nibh at tortor volutpat non rhoncus nunc mattis. Curabitur pulvinar, leo vel condimentum malesuada, dui urna tincidunt dolor, ac feugiat odio ligula non arcu. Pellentesque lacinia mollis lorem, ut viverra orci aliquam ac. Fusce posuere pretium consequat.</p>
				<p>Etiam viverra nisi id urna tristique sagittis. Ut dui tortor, ullamcorper id lacinia non, porttitor ut quam. Aenean nibh elit, posuere id congue ac, facilisis faucibus eros. Vestibulum sed nulla felis. Ut neque turpis, dignissim eu pulvinar id, tempus quis mi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
			</div>
			<div class="article">
				<h2>With a little help from</h2>
				<img src="angel3.gif"  class="img-topleft"/>
				<p>In viverra dolor nec ligula tristique porta. Nullam a augue tellus. Sed porta nisl vel felis auctor eleifend. Pellentesque mattis eros in enim dapibus id laoreet ligula vestibulum.</p>
				<p>Duis vel nis nec tortor consectetur tempor. Procter nisl sapien, accumsan et aliquam at, pharetra sed eros. Integer sed erat quis tortor dictum suscipit. Procter malesuada interdum turpis, eget tempus velit porta id. Procter sit amet arcu et dolor dapibus iaculis. Nullam non risus ante. Nunc ultrices ultricies bibendum. Ut in libero neque. Sed laoreet, purus eget consequat ullamcorper, sapien augue placerat nibh, at blandit.</p>
			</div>
			<div class="article">
				<h2>Guide</h2>
				<p>Curabitur non eros. Nullam hendrerit bibendum justo. Fusce iaculis, est quis lacinia pretium, pede metus molestie lacus, at gravida wisi ante at libero. <a href="http://wwww.url.com" class="readmore">read more...</a></p></p></p>
			</div>
		</div>
		<?php include 'footer.php';?>
	</div>	
</body>
</html>

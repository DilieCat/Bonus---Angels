<div class="footer">
			<p class="footertext"> &copy;2012 Mauris eleifend nulla egt mauris.</p>
		</div>